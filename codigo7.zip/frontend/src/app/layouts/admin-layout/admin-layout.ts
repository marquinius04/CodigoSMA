import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Sidebar } from '../../commons/sidebar/sidebar';
import { Navbar } from '../../commons/navbar/navbar';

@Component({
  selector: 'app-admin-layout',
  imports: [RouterOutlet, Sidebar, Navbar],
  templateUrl: './admin-layout.html',
  styleUrl: './admin-layout.css'
})
export class AdminLayout {}