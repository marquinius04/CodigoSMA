import { Routes } from '@angular/router';
import { Dashboard } from './dashboard/dashboard';
import { Users } from './users/users';

export const adminRoutes: Routes = [
  { path: '', component: Dashboard },
  { path: 'users', component: Users },
  { path: '**', redirectTo: '' } // Redirección interna de la zona admin
];