/*
Importación de módulos
*/
const express = require('express');
const cors = require('cors');
require('dotenv').config();

// Importar el módulo de conexión
const { dbConnection } = require('./database/configdb');

// Crear una aplicación de express
const app = express();

// Conectar a la base de datos SQLite
dbConnection();

app.use(cors());

// Abrir la aplicacíon en el puerto 3000
app.listen(process.env.PORT, () => {
    console.log('Servidor corriendo en el puerto ' + process.env.PORT);
});

// Cuando se haga una solicitud GET a esta ruta, se responderá con un "Hola mundo"
app.get('/', (req, res) => {
    res.json({
        ok: true,
        msg: 'Hola mundo'
    });
});