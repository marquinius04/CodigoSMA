const sqlite3 = require('sqlite3');
const { open } = require('sqlite');

let db;

const dbConnection = async () => {
    try {
        db = await open({
            filename: process.env.DB_PATH || './database/database.sqlite',
            driver: sqlite3.Database
        });

        console.log('DB online (SQLite)');
        return db;
    } catch (error) {
        console.log(error);
        throw new Error('Error al iniciar la BD SQLite');
    }
};

const getDb = () => db;

module.exports = {
    dbConnection,
    getDb
};