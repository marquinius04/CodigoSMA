import { Routes } from '@angular/router';
import { AuthLayout } from './layouts/auth-layout/auth-layout';
import { Login } from './auth/login/login';
import { AdminLayout } from './layouts/admin-layout/admin-layout';
import { Dashboard } from './pages/dashboard/dashboard';
import { Users } from './pages/users/users';

export const routes: Routes = [
  { 
    path: 'login', 
    component: AuthLayout,
    children: [
      { path: '', component: Login }
    ]
  },
  { 
    path: 'dashboard', 
    component: AdminLayout,
    children: [
      { path: '', component: Dashboard },
      { path: 'users', component: Users },
      { path: '**', redirectTo: '' } // Atrapa subrutas erróneas (ej. /dashboard/berenjena) y redirige al panel
    ]
  },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: '**', redirectTo: 'login' } // Atrapa cualquier ruta global no definida y redirige al login
];